// Cloudflare Pages Worker - Simplified for compatibility
export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;
    
    // Directly serve static assets
    if (path.startsWith('/_next/') || 
        path.match(/\.(ico|svg|png|jpg|jpeg|css|js)$/)) {
      return fetch(request);
    }
    
    // For all routes, try to serve index.html
    try {
      return fetch(new URL('/index.html', request.url));
    } catch (e) {
      return new Response('Page not found', { status: 404 });
    }
  }
};
